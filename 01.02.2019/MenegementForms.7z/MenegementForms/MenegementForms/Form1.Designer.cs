﻿namespace MenegementForms
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.lblName = new System.Windows.Forms.Label();
            this.lblSurname = new System.Windows.Forms.Label();
            this.txSurname = new System.Windows.Forms.TextBox();
            this.txName = new System.Windows.Forms.TextBox();
            this.cb = new System.Windows.Forms.CheckBox();
            this.rbBlack = new System.Windows.Forms.RadioButton();
            this.rbBrown = new System.Windows.Forms.RadioButton();
            this.rbBeig = new System.Windows.Forms.RadioButton();
            this.grbColor = new System.Windows.Forms.GroupBox();
            this.lbCar = new System.Windows.Forms.ListBox();
            this.lblMark = new System.Windows.Forms.Label();
            this.btnOnly = new System.Windows.Forms.Button();
            this.clbComplect = new System.Windows.Forms.CheckedListBox();
            this.lbDate = new System.Windows.Forms.Label();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.grbColor.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(12, 41);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(29, 13);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Имя";
            // 
            // lblSurname
            // 
            this.lblSurname.AutoSize = true;
            this.lblSurname.Location = new System.Drawing.Point(12, 95);
            this.lblSurname.Name = "lblSurname";
            this.lblSurname.Size = new System.Drawing.Size(56, 13);
            this.lblSurname.TabIndex = 1;
            this.lblSurname.Text = "Фамилия";
            // 
            // txSurname
            // 
            this.txSurname.Location = new System.Drawing.Point(94, 88);
            this.txSurname.Name = "txSurname";
            this.txSurname.Size = new System.Drawing.Size(189, 20);
            this.txSurname.TabIndex = 2;
            // 
            // txName
            // 
            this.txName.Location = new System.Drawing.Point(94, 41);
            this.txName.Name = "txName";
            this.txName.Size = new System.Drawing.Size(189, 20);
            this.txName.TabIndex = 3;
            // 
            // cb
            // 
            this.cb.AutoSize = true;
            this.cb.Location = new System.Drawing.Point(12, 167);
            this.cb.Name = "cb";
            this.cb.Size = new System.Drawing.Size(107, 17);
            this.cb.TabIndex = 4;
            this.cb.Text = "Кожаный Салон";
            this.cb.UseVisualStyleBackColor = true;
            this.cb.CheckedChanged += new System.EventHandler(this.cb_CheckedChanged);
            // 
            // rbBlack
            // 
            this.rbBlack.AutoSize = true;
            this.rbBlack.Location = new System.Drawing.Point(20, 29);
            this.rbBlack.Name = "rbBlack";
            this.rbBlack.Size = new System.Drawing.Size(65, 17);
            this.rbBlack.TabIndex = 5;
            this.rbBlack.TabStop = true;
            this.rbBlack.Text = "Черный";
            this.rbBlack.UseVisualStyleBackColor = true;
            // 
            // rbBrown
            // 
            this.rbBrown.AutoSize = true;
            this.rbBrown.Location = new System.Drawing.Point(20, 102);
            this.rbBrown.Name = "rbBrown";
            this.rbBrown.Size = new System.Drawing.Size(87, 17);
            this.rbBrown.TabIndex = 6;
            this.rbBrown.TabStop = true;
            this.rbBrown.Text = "Коричневый";
            this.rbBrown.UseVisualStyleBackColor = true;
            // 
            // rbBeig
            // 
            this.rbBeig.AutoSize = true;
            this.rbBeig.Location = new System.Drawing.Point(20, 65);
            this.rbBeig.Name = "rbBeig";
            this.rbBeig.Size = new System.Drawing.Size(72, 17);
            this.rbBeig.TabIndex = 7;
            this.rbBeig.TabStop = true;
            this.rbBeig.Text = "Бежевый";
            this.rbBeig.UseVisualStyleBackColor = true;
            // 
            // grbColor
            // 
            this.grbColor.BackColor = System.Drawing.Color.Transparent;
            this.grbColor.Controls.Add(this.rbBrown);
            this.grbColor.Controls.Add(this.rbBeig);
            this.grbColor.Controls.Add(this.rbBlack);
            this.grbColor.Location = new System.Drawing.Point(12, 200);
            this.grbColor.Name = "grbColor";
            this.grbColor.Size = new System.Drawing.Size(129, 147);
            this.grbColor.TabIndex = 8;
            this.grbColor.TabStop = false;
            this.grbColor.Text = "Цвет кожи";
            this.grbColor.Visible = false;
            this.grbColor.Enter += new System.EventHandler(this.grbColor_Enter);
            // 
            // lbCar
            // 
            this.lbCar.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.lbCar.FormattingEnabled = true;
            this.lbCar.Items.AddRange(new object[] {
            "Audi",
            "Mercedes",
            "BMV",
            "Bently",
            "Maserati"});
            this.lbCar.Location = new System.Drawing.Point(12, 379);
            this.lbCar.MultiColumn = true;
            this.lbCar.Name = "lbCar";
            this.lbCar.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lbCar.Size = new System.Drawing.Size(136, 147);
            this.lbCar.TabIndex = 9;
            this.lbCar.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // lblMark
            // 
            this.lblMark.AutoSize = true;
            this.lblMark.Location = new System.Drawing.Point(12, 359);
            this.lblMark.Name = "lblMark";
            this.lblMark.Size = new System.Drawing.Size(86, 13);
            this.lblMark.TabIndex = 10;
            this.lblMark.Text = "Марка Машины";
            // 
            // btnOnly
            // 
            this.btnOnly.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnOnly.Location = new System.Drawing.Point(632, 453);
            this.btnOnly.Name = "btnOnly";
            this.btnOnly.Size = new System.Drawing.Size(118, 34);
            this.btnOnly.TabIndex = 11;
            this.btnOnly.Text = "Заказ";
            this.btnOnly.UseVisualStyleBackColor = true;
            this.btnOnly.Click += new System.EventHandler(this.btnOnly_Click);
            // 
            // clbComplect
            // 
            this.clbComplect.BackColor = System.Drawing.Color.DarkGray;
            this.clbComplect.CheckOnClick = true;
            this.clbComplect.FormattingEnabled = true;
            this.clbComplect.Items.AddRange(new object[] {
            "ABS",
            "Аудио",
            "Выезжающие подножки",
            "Деревянная фурнитура",
            "Кондиционер",
            "Мониторы пассажирских сидений",
            "Подогрев зеркал заднего вида",
            "Подогрев руля",
            "Подсветка салона"});
            this.clbComplect.Location = new System.Drawing.Point(187, 379);
            this.clbComplect.Name = "clbComplect";
            this.clbComplect.Size = new System.Drawing.Size(210, 154);
            this.clbComplect.Sorted = true;
            this.clbComplect.TabIndex = 12;
            // 
            // lbDate
            // 
            this.lbDate.AutoSize = true;
            this.lbDate.Location = new System.Drawing.Point(575, 19);
            this.lbDate.Name = "lbDate";
            this.lbDate.Size = new System.Drawing.Size(83, 13);
            this.lbDate.TabIndex = 13;
            this.lbDate.Text = "Дата доставки";
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(578, 41);
            this.monthCalendar1.MaxSelectionCount = 10;
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 14;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(800, 538);
            this.Controls.Add(this.monthCalendar1);
            this.Controls.Add(this.lbDate);
            this.Controls.Add(this.clbComplect);
            this.Controls.Add(this.btnOnly);
            this.Controls.Add(this.lblMark);
            this.Controls.Add(this.lbCar);
            this.Controls.Add(this.grbColor);
            this.Controls.Add(this.cb);
            this.Controls.Add(this.txName);
            this.Controls.Add(this.txSurname);
            this.Controls.Add(this.lblSurname);
            this.Controls.Add(this.lblName);
            this.Name = "MainForm";
            this.Text = "Покупка АВТО";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.grbColor.ResumeLayout(false);
            this.grbColor.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblSurname;
        private System.Windows.Forms.TextBox txSurname;
        private System.Windows.Forms.TextBox txName;
        private System.Windows.Forms.CheckBox cb;
        private System.Windows.Forms.RadioButton rbBlack;
        private System.Windows.Forms.RadioButton rbBrown;
        private System.Windows.Forms.RadioButton rbBeig;
        private System.Windows.Forms.GroupBox grbColor;
        private System.Windows.Forms.ListBox lbCar;
        private System.Windows.Forms.Label lblMark;
        private System.Windows.Forms.Button btnOnly;
        private System.Windows.Forms.CheckedListBox clbComplect;
        private System.Windows.Forms.Label lbDate;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
    }
}

