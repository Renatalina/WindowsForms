﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MenegementForms
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }
       
        private void cb_CheckedChanged(object sender, EventArgs e)
        {

            grbColor.Visible = cb.Checked ? true : false;
            
        }
        private void grbColor_Enter(object sender, EventArgs e)
        {
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbCar.SelectedItem != null)
            {
                //MessageBox.Show(lbCar.SelectedItem.ToString());
                //получим сообщение, какую машину мы выбрали
                //для кода ниже, нужно его раскоментить
            }
        }

        private void btnOnly_Click(object sender, EventArgs e)
        {
            StringBuilder builder = new StringBuilder();
            //это для строки, когда мы постоянно перезаписываем строку, когда мы постоянно что-то добавляем в строку
            //она как Стринг,  похоже 
           
            foreach(var item in lbCar.SelectedItems)
            {
                builder.Append($"{item.ToString()}\n");
            }
            
            foreach (var item in clbComplect.CheckedItems)
            {
                builder.Append($"{item.ToString()}\n");
            }
            MessageBox.Show(builder.ToString());
        }
    }
}
