﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MenegementForms
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }
       
        private void cb_CheckedChanged(object sender, EventArgs e)
        {

            grbColor.Visible = cb.Checked ? true : false;
            
        }
        private void grbColor_Enter(object sender, EventArgs e)
        {
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbCar.SelectedItem != null)
            {
                //MessageBox.Show(lbCar.SelectedItem.ToString());
                //получим сообщение, какую машину мы выбрали
                //для кода ниже, нужно его раскоментить
            }
        }

        private void btnOnly_Click(object sender, EventArgs e)
        {
            StringBuilder builder = new StringBuilder();
            //это для строки, когда мы постоянно перезаписываем строку, когда мы постоянно что-то добавляем в строку
            //она как Стринг,  похоже 
            builder.Append($"Name: {txName.Text}\r\n");
            builder.Append($"Surname: {txSurname.Text}\r\n");
            builder.Append($"Telephone: {maskedTextBox1.Text}\r\n");

            builder.Append($"\r\nCar:");
            foreach (var item in lbCar.SelectedItems)
            {
                builder.Append($"{item.ToString()}\t");
            }
            
            if(cb.Checked)
            {
                builder.Append($"\r\nColor car:");
                foreach (Control item in grbColor.Controls)//Контрол это базовый класс, который сам может пройтись по коллекции
                {
                    if ((item as RadioButton).Checked)
                    {
                        builder.Append($"{item.Text}\t");
                        break;
                    }
                }
            }
            builder.Append($"\r\nComplectation: \t");
            foreach (var item in clbComplect.CheckedItems)
            {
                builder.Append($"{item.ToString()}\t");
            }
            builder.Append($"\r\nSeller: \t");
            if (comboBox1.Text!=null)
            {
                builder.Append($"{comboBox1.Text}\t");               
            }
            
            //MessageBox.Show(builder.ToString());
           
            builder.Append($"\nData delivery: {monthCalendar1.SelectionStart.Day}\t");


            textBox1.Text = builder.ToString();//здесь идет запись в текстовое поле
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void maskedTextBox1_Click(object sender, EventArgs e)
        {
            maskedTextBox1.SelectionStart = 1;//курсор будет стоять в самом начале
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            MessageBox.Show($"Error: {e.RejectionHint} Position: {e.Position}");
        }
    }
}
